

import prismaClient from "../../prisma";

interface UnfinishedOrdersRequest {
  date: string;
}

class ListUnfinishedOrdersService {
  async execute({ date }: UnfinishedOrdersRequest) {
    
    const orders = await prismaClient.pedido.findMany({
      where: {
        status: false, 
        criado_em: {
          gte: new Date(date),
        },
      },
    });

    return orders;
  }
}

export { ListUnfinishedOrdersService };
