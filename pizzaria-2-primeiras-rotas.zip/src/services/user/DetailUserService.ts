import prismaClient from "../../prisma";

class DetailUserService {

    async execute(user_id: string) {
        
        
    }

}

export { DetailUserService };